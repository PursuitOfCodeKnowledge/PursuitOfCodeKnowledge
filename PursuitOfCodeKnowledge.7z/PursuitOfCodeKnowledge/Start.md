******************************************************************Погоня за Кодовым Знанием*******************************************************************************

Привет Старина! Добро пожаловать в кибермир! Если читаешь эти строки, то ты уже в погоне за кодовым знанием! Чтобы начать играть, тебе нужно распаковать архив с игрой (Game.7z).
Но есть трудность архив с паролем. Твоя задача узнать пароль от архива, ответь на простой вопрос: "В каком году появилась Русь?". Затем перейти в каталог Game с игрой
и перейти на нулевой уровень в каталог LevelZero.

Hello Old Man! Welcome to the cyberworld! If you are reading these lines, then you are already in pursuit of code knowledge! To start playing, you need to unpack the archive with the game (Game.7z).
But there is a difficulty with the password archive. Your task is to find out the password from the archive, answer a simple question: "In what year did Russia appear?". Then go to the Game directory with the game
and go to Level zero in the Level Zero directory. 

**************************************************************************************************************************************************************************
